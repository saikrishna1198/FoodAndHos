# Food-and-Hospitality-System
It is django framework project based on Javascript!!!
